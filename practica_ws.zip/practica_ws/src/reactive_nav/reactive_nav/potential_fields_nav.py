#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import LaserScan
from nav_msgs.msg import Odometry
from geometry_msgs.msg import PoseStamped, Twist
import numpy as np
from scipy import linalg




class MyNode(Node):

    
    def __init__(self):
        super().__init__("first_node")
        self.subLaser = self.create_subscription(LaserScan, '/laser1', self.callbackLaser, 10)
        self.subGoalPose = self.create_subscription(PoseStamped, '/goal_pose', self.callbackGoalPose, 10)
        self.subTruePose = self.create_subscription(Odometry, '/base_pose_ground_truth', self.callbackTruePose, 10)
        self.pub = self.create_publisher(Twist, '/cmd_vel', 10)  # Only create the publisher, no callback

        # Inicializar atributos y banderas
        self.laser = None
        self.goalPose = None
        self.truePose = None
        self.messages_received = {'laser': False, 'goalPose': False, 'truePose': False}
        self.destinoFinal = False

    def callbackLaser(self, msg):
        self.laser = msg
        self.messages_received['laser'] = True
        self.calculate_and_publish()

    def callbackGoalPose(self, msg):
        if self.messages_received['goalPose'] == False:    
            self.goalPose = np.vstack([[msg.pose.position.x], [msg.pose.position.y]])
            self.messages_received['goalPose'] = True
            self.calculate_and_publish()

    def callbackTruePose(self, msg):
        # Almacenar datos de Odometry
        self.true_pose_data = msg
        pose_data = msg.pose.pose
        position_x = pose_data.position.x
        position_y = pose_data.position.y

        # Supongamos que tienes un mensaje Odometry llamado "odometry_msg"
        q0 = msg.pose.pose.orientation.w
        q1 = msg.pose.pose.orientation.x
        q2 = msg.pose.pose.orientation.y
        q3 = msg.pose.pose.orientation.z

        # Calcula los ángulos de Euler (yaw, pitch, roll)
        yaw_angle = np.arctan2(2 * (q0*q3 + q1*q2), 1 - 2 * (q2**2 + q3**2))
        
        self.trueTheta = yaw_angle
        self.truePose = np.vstack([[position_x],[position_y]])
        self.messages_received['truePose'] = True
        self.calculate_and_publish()

    def calculate_and_publish(self):
        if all(self.messages_received.values()):
            # Todos los mensajes han sido recibidos, ahora puedes calcular y publicar
            RadiusOfInfluence = 4
            KObstacles = self.calculate_obstacles(self.laser.ranges, RadiusOfInfluence)
            v, theta = self.total_force(self.truePose, self.goalPose, self.laser, RadiusOfInfluence, KObstacles, 1.75)
            if self.destinoFinal == False:
                self.publish_cmd_vel(v, theta)
            # Reiniciar las banderas y esperar para recibir nuevos valores
            self.messages_received = {'laser': False, 'truePose': False}
            self.laser = None
            self.truePose = None

    def publish_cmd_vel(self, v, theta):
        twist_msg = Twist()
        twist_msg.linear.x = np.sqrt(v[0]**2 + v[1]**2)
        twist_msg.angular.z = theta
        self.pub.publish(twist_msg)


    def repulsive_force(self, xRobot, Laser, RadiusOfInfluence, KObstacles):
        # Obtener posiciones de objetos a partir de los datos de escaneo láser
        object_positions = self.calculate_object_positions(Laser)

        # Calcular la distancia de cada obstáculo al robot
        p_to_object = xRobot - object_positions
        distances = np.sqrt(np.sum(p_to_object**2, axis=0))

        # Identificar obstáculos dentro del radio de influencia
        iInfluential = np.where(distances <= RadiusOfInfluence)[0]

        self.get_logger().info(f"True Pose: (x-> {self.truePose[0]}, y-> {self.truePose[1]})")
        #self.get_logger().info(f"Distancias: {distances}")

        if iInfluential.shape[0] > 0:
            p_to_object = p_to_object[:, iInfluential]
            distances = distances[iInfluential]

            # Calcular la fuerza repulsiva para cada obstáculo cercano
            Fi = np.vstack([
                np.sum(((1/distances) - 1/RadiusOfInfluence) * (1/distances**2) * (p_to_object[0, :] / distances)),
                np.sum(((1/distances) - 1/RadiusOfInfluence) * (1/distances**2) * (p_to_object[1, :] / distances))
            ])

            FRep = KObstacles * Fi.reshape((2,1))

        else:
            # No hay obstáculos cercanos
            FRep = np.zeros((2, 1))

        return FRep

    
    def calculate_object_positions(self, scan_msg):
        # Extraer datos relevantes del mensaje
        angle_min = scan_msg.angle_min
        angle_increment = scan_msg.angle_increment
        range_min = scan_msg.range_min
        ranges = scan_msg.ranges

        # Filtrar valores fuera del rango válido
        valid_ranges = [r for r in ranges if range_min <= r <= scan_msg.range_max]

        # Calcular coordenadas (x, y) de los objetos
        x_positions = []
        y_positions = []
        current_angle = angle_min

        for r in valid_ranges:
            x = self.truePose[0] + r * np.cos(self.trueTheta + current_angle)
            y = self.truePose[1] + r * np.sin(self.trueTheta + current_angle)

            x_positions.append(x)
            y_positions.append(y)

            # Actualizar el ángulo actual para el siguiente rango
            current_angle += angle_increment

        # Convertir las listas en np arrays
        x_positions_array = np.array(x_positions)
        y_positions_array = np.array(y_positions)

        

        matriz_resultado = np.hstack((x_positions_array, y_positions_array)).T

        # Mostrar las posiciones de los objetos con etiquetas
        #self.get_logger().info(f"Matriz posiciones: {matriz_resultado}")

        # Devolver como un np.vstack si es necesario
        return matriz_resultado

    
    def attractive_force(self, KGoal, GoalError):       
        FAtt = -KGoal*GoalError
        FAtt /= np.linalg.norm(GoalError) # Normalization
        FAtt = FAtt.reshape((2, 1))  # Aseguramos que FAtt tenga la forma (2, 1)

        return FAtt
    
    def total_force(self, xRobot, xGoal, Laser, RadiusOfInfluence, KObstacles, KGoal):

        GoalError = xRobot - xGoal
        
        d = np.sqrt(np.sum(GoalError**2, axis=0))

        if d > 0.5:  # Teniendo en cuenta 0.5 de error

            FRep = self.repulsive_force(xRobot, Laser, RadiusOfInfluence, KObstacles)
            FAtt = self.attractive_force(KGoal, GoalError)


            FTotal = FAtt+FRep
            FTotal /= linalg.norm(FTotal)
            
            v = ((FTotal[0,0]*np.cos(self.trueTheta) + FTotal[1,0]*np.sin(self.trueTheta)), (-FTotal[0,0]*np.sin(self.trueTheta) + FTotal[1,0]*np.cos(self.trueTheta)))
            theta = np.arctan2(v[1], v[0])

            self.get_logger().info(f"Valores de repulsión: {FRep} \n Valores de atracción: {FAtt} \n Valores de Ftotal: {FTotal}")

        else:

            v = 0
            theta = 0
            self.destinoFinal = True

        return v, theta

        
    def calculate_obstacles(self, laser, RadiusOfInfluence):
        laser_np = np.array(laser)
        b = np.sum(laser_np <= RadiusOfInfluence)
        return b
        

def main(args=None):
    rclpy.init(args=args)
    node = MyNode()

    rclpy.spin_once(node)

    # Continue spinning and calculating until shutdown
    while (rclpy.ok() and not node.destinoFinal) :
        rclpy.spin_once(node)

    
    node.get_logger().info("DESTINO ALCANZADO, PROGRAMA FINALIZADO CON ÉXITO")

    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
